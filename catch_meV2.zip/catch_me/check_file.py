# check_all_files.py
import os
from username import get_username

def check_file_all_local(file_name,to_do): #check file all local
    # รับ list ของทุกโฟลเดอร์ในระบบไฟล์
    all_folders = [root for root, dirs, files in os.walk("C:\\")]

    for folder_path in all_folders:
        file_path = os.path.join(folder_path, file_name)
        
        if os.path.exists(file_path):
            print(f"The file {file_path} exists.")
            
        #else:
            #print(f"The file {file_path} does not exist.")

def check_to_path(file_names):
    username = get_username()
    folders_to_check = [
        #f"C:\\Users\\{username}\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup",
        f"C:\\Windows\\Temp",
        f"C:\\Users\\{username}\\Downloads"
    ]

    existing_files = []

    for folder_path in folders_to_check:
        for file_name in file_names:
            file_path = os.path.join(folder_path, file_name)

            if os.path.isfile(file_path):
                print(f"The file {file_path} exists.")
                existing_files.append(file_path)

    return existing_files

""" if __name__ == "__main__":
    files_to_check = ["test1.py", "my_program.exe", "test3.py", "test4.py"]
    result = check_to_path(files_to_check)

    if result:
        print("All files exist.")
        print(result)
    else:
        print("Some files do not exist.") """