import shutil
import os
from username import get_username
def move_files_to_folder(file_extension='.txt', destination_folder='move'):
    # ระบุ path ที่ desktop อยู่
    username = get_username()
    folder_path =f'C:\\Users\\{username}\\AppData\\Local\\Temp' #chang folder_path to desktop_path (use)
    desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')

    # สร้างโฟลเดอร์ที่จะย้ายไฟล์ไป
    destination_path = os.path.join(folder_path, destination_folder)
    os.makedirs(destination_path, exist_ok=True)

    # ใช้ shutil.move() เพื่อย้ายไฟล์ทั้งหมดใน desktop ไปยัง destination folder
    moved_files = []
    for filename in os.listdir(desktop_path):
        if filename.endswith(file_extension):
            file_path = os.path.join(desktop_path, filename)
            shutil.move(file_path, destination_path)
            moved_files.append(filename)

    return moved_files

""" if __name__ == "__main__":
    moved_files = move_files_to_folder()
    print(f"ไฟล์ทั้งหมดบน desktop ถูกย้ายไปยังโฟลเดอร์ 'move' แล้ว:")
    for file in moved_files:
        print(file) """
