# my_module.py

import subprocess
from username import get_username

def run_bat_file(path,name,types):
    username = get_username()
    #file_path = f'C://Users//{username}//Desktop//{name}.{types}'
    file_path = f'{path}{name}.{types}'
    #print(file_path)
    try:
        subprocess.run(file_path, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")

def run_powershell_file(name,types):
    username = get_username()
    file_path = f'C://Users//{username}//Desktop//{name}.{types}'
    
    try:
        subprocess.run(["powershell", "-ExecutionPolicy", "Bypass", "-File", file_path], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")

# เพื่อทดสอบเรียกใช้ run_bat_file จะได้
if __name__ == "__main__":
    """ username = get_username()
    namepath = "C:\\Windows\\Temp\\"
    namefile = "task"
    file_types = "bat"
    run_bat_file(namepath,namefile,file_types)

    namepathstarp = f"C:\\Users\\{username}\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
    namefilepersistance = "persistence"
    file_types = "bat"
    run_bat_file(namepathstarp,namefilepersistance,file_types) """
   

