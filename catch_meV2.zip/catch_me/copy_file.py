import shutil

def copy_file(source_path,destination_folder):
    shutil.copy(source_path,destination_folder)

if __name__ == "__main__":
    source_path = "C:\\Users\\itsupport\\Downloads\\Antivirus.exe"
    destination_folder = "C:\\Users\\itsupport\\Desktop\\test.exe"
    copy_file(source_path,destination_folder)