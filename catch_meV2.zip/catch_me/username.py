# username_module.py

import os

def get_username():
    name = os.path.basename(os.path.expanduser('~'))
    return name

if __name__ == "__main__":
    # ส่วนนี้จะถูกทำงานเมื่อโมดูลถูกรันโดยตรง
    username = get_username()
    print(username)
