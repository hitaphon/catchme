# countdown_timer.py
import tkinter as tk

class CountdownTimer:
    def __init__(self, root, seconds):
        self.root = root
        self.seconds = seconds

        # สร้าง Label เพื่อแสดงเวลานับถอยหลัง
        self.label = tk.Label(root, text="", font=("Arial", 20), fg="green", bg="black")
        self.label.pack()

        # เริ่มนับถอยหลัง
        self.update_timer()

    def update_timer(self):
        if self.seconds > 0:
            # แปลงเวลาให้เป็น นาที:วินาที
            minutes, seconds = divmod(self.seconds, 60)
            timer_text = f"{minutes:02d}:{seconds:02d}"

            # แสดงเวลานับถอยหลังใน Label
            self.label.config(text=timer_text)

            # ลดเวลาลง 1 วินาที
            self.seconds -= 1

            # อัปเดตนาฬิกาทุก 1000 มิลลิวินาที (1 วินาที)
            self.root.after(1000, self.update_timer)
        else:
            # เมื่อนับถอยหลังเสร็จสิ้น
            self.label.config(text="Time's up!")



# ในกรณีที่ถูกเรียกโดยตรง
if __name__ == "__main__":
    

    root = tk.Tk()
    root.title('Catch Me')
    root.configure(bg="black")

    # กำหนดเวลานับถอยหลัง (วินาที)
    countdown_seconds = 3600  # ตั้งค่าเป็น 5 นาที

    label_text = "\n I have moved files on your desktop to another location.\nIf you want the files back, Catch me if you can."
    label = tk.Label(root, text=label_text, font=("Arial", 16), foreground="green", background="black")
    label.pack()

    # สร้าง CountdownTimer instance
    countdown_timer = CountdownTimer(root, countdown_seconds)

    # แสดง Tkinter window
    root.mainloop()